Set-ExecutionPolicy RemoteSigned
Compress-Archive -Path ..\ArduinoProps -DestinationPath ArduinoProps